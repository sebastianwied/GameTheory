from memoryone import *

payoff = (5,3,1,0)

agentTypes = {'BLANK':(BLANK,0), 'CU':(CU,1), 'RAND':(RAND,2), 'DU':(DU,3), 'TFT':(TFT,4), 'STFT':(STFT,5), 'GRIM':(GRIM,6), 'CP':(CP,7)}

agentIDs = {0:'BLANK', 1:'CU', 2:'RAND', 3:'DU', 4:'TFT', 5:'STFT', 6:'GRIM', 7:'CP'}
