# How to run
For the grid tournament, run cligui.py. Follow instructions it prompts you. Something is wrong with the first option so just type n. Default neighborhood size is 1.

For the round robin tournament, run vee.py